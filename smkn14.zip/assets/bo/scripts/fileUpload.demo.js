/**
 * Theme: Ninja Admin Template
 * Author: NinjaTeam
 * Module/App: File Upload Demo
 */

(function($) {
	"use strict";

	$('.dropify').dropify();

})(jQuery);