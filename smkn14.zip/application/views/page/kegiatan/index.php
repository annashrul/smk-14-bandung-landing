<?php
$this->load->view('page/kegiatan/osis');
$this->load->view('page/kegiatan/eskul');
$this->load->view('page/kegiatan/pramuka');
?>