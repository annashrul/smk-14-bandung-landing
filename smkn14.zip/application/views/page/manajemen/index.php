<?php
$this->load->view('page/manajemen/kepala_sekolah');
$this->load->view('page/manajemen/kepala_tu');
$this->load->view('page/manajemen/wakil_kepala');
$this->load->view('page/manajemen/dewan');
$this->load->view('page/manajemen/kajur');
?>