<?php $this->load->view('layout/tambahan') ?>
<?php $this->load->view('layout/header') ?>
<section class="team-one">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3">
                        <div class="team-one__single">
                            <div class="team-one__image">
                                <img src="<?=base_url();?>assets/img/6.jpg" alt="">
                            </div><!-- /.team-one__image -->
                            <div class="team-one__content">
                                <h2 class="team-one__name">Nama Wakil Sekolah</h2>
                                <!-- /.team-one__name -->
                                <p class="team-one__designation">NIDN</p><!-- /.team-one__designation -->
                                <p class="team-one__text">Deskripsi</p>
                                <!-- /.team-one__text -->
                            </div><!-- /.team-one__content -->
                        </div><!-- /.team-one__single -->
                    </div><!-- /.col-lg-3 -->

                    <div class="col-lg-3">
                        <div class="team-one__single">
                            <div class="team-one__image">
                                <img src="<?=base_url();?>assets/img/6.jpg" alt="">
                            </div><!-- /.team-one__image -->
                            <div class="team-one__content">
                                <h2 class="team-one__name">Nama Wakil Sekolah</h2>
                                <!-- /.team-one__name -->
                                <p class="team-one__designation">NIDN</p><!-- /.team-one__designation -->
                                <p class="team-one__text">Deskripsi</p>
                                <!-- /.team-one__text -->
                            </div><!-- /.team-one__content -->
                        </div><!-- /.team-one__single -->
                    </div><!-- /.col-lg-3 -->

                    <div class="col-lg-3">
                        <div class="team-one__single">
                            <div class="team-one__image">
                                <img src="<?=base_url();?>assets/img/6.jpg" alt="">
                            </div><!-- /.team-one__image -->
                            <div class="team-one__content">
                                <h2 class="team-one__name">Nama Wakil Sekolah</h2>
                                <!-- /.team-one__name -->
                                <p class="team-one__designation">NIDN</p><!-- /.team-one__designation -->
                                <p class="team-one__text">Deskripsi</p>
                                <!-- /.team-one__text -->
                            </div><!-- /.team-one__content -->
                        </div><!-- /.team-one__single -->
                    </div><!-- /.col-lg-3 -->

                    <div class="col-lg-3">
                        <div class="team-one__single">
                            <div class="team-one__image">
                                <img src="<?=base_url();?>assets/img/6.jpg" alt="">
                            </div><!-- /.team-one__image -->
                            <div class="team-one__content">
                                <h2 class="team-one__name">Nama Wakil Sekolah</h2>
                                <!-- /.team-one__name -->
                                <p class="team-one__designation">NIDN</p><!-- /.team-one__designation -->
                                <p class="team-one__text">Deskripsi</p>
                                <!-- /.team-one__text -->
                            </div><!-- /.team-one__content -->
                        </div><!-- /.team-one__single -->
                    </div><!-- /.col-lg-3 -->

                    <div class="col-lg-3">
                        <div class="team-one__single">
                            <div class="team-one__image">
                                <img src="<?=base_url();?>assets/img/6.jpg" alt="">
                            </div><!-- /.team-one__image -->
                            <div class="team-one__content">
                                <h2 class="team-one__name">Nama Wakil Sekolah</h2>
                                <!-- /.team-one__name -->
                                <p class="team-one__designation">NIDN</p><!-- /.team-one__designation -->
                                <p class="team-one__text">Deskripsi</p>
                                <!-- /.team-one__text -->
                            </div><!-- /.team-one__content -->
                        </div><!-- /.team-one__single -->
                    </div><!-- /.col-lg-3 -->

                    <div class="col-lg-3">
                        <div class="team-one__single">
                            <div class="team-one__image">
                                <img src="<?=base_url();?>assets/img/6.jpg" alt="">
                            </div><!-- /.team-one__image -->
                            <div class="team-one__content">
                                <h2 class="team-one__name">Nama Wakil Sekolah</h2>
                                <!-- /.team-one__name -->
                                <p class="team-one__designation">NIDN</p><!-- /.team-one__designation -->
                                <p class="team-one__text">Deskripsi</p>
                                <!-- /.team-one__text -->
                            </div><!-- /.team-one__content -->
                        </div><!-- /.team-one__single -->
                    </div><!-- /.col-lg-3 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </section><!-- /.team-one team-page -->