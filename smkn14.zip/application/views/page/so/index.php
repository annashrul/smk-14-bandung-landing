<?php
$this->load->view('page/so/bagan_struktur');
$this->load->view('page/so/divisi');

?>