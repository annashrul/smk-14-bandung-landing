<?php $this->load->view('layout/tambahan') ?>
<?php $this->load->view('layout/header') ?>


<section class="team-details">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-4">
                        <div class="blog-one__single">
                            <div class="blog-one__image">
                                <img src="<?=base_url();?>assets/img/akreditasi.jpg" alt="" widht="100">
                            </div><!-- /.blog-one__image -->
                        </div><!-- /.blog-one__single -->
                    </div><!-- /.col-lg-8 -->
                    <div class="col-lg-7" style="height:15px">
                                <h2 class="blog-one__title">Nama Perusahaan</h2><!-- /.blog-one__title -->
                                <p class="blog-one__text">Deskripsi <a href="">Lihat Lebih</a></p><!-- /.blog-one__text -->
                    </div>
                    <div class="col-lg-1">
                    	<div class="blog-one__meta">
                            <a data-toggle="tooltip" data-placement="top" title="bagikan" href="#"><i class="fa fa-share"></i></a>
 						</div><!-- /.blog-one__meta -->
 					</div>
                </div><!-- /.row -->
            </div><!-- /.container -->
</section><!-- /.blog-details -->

