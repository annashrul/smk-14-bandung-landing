<?php $this->load->view('layout/tambahan') ?>
<?php $this->load->view('layout/header') ?>


<section class="team-one">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4">
                        <div class="blog-one__single">
                            <div class="blog-one__image">
                                <img src="<?=base_url();?>assets/img/lapangan.jpg" alt="">
                                <a class="blog-one__plus" href="news-details.html"><i class="kipso-icon-plus-symbol"></i>
                                    <!-- /.kipso-icon-plus-symbol --></a>
                            </div><!-- /.blog-one__image -->
                            <div class="blog-one__content text-center">
                                <h2>Tittle</h2>
                                <p class="blog-one__text">Deskripsi</p><!-- /.blog-one__text -->
                                <a href="news-details.html" class="blog-one__link">Read More</a><!-- /.blog-one__link -->
                            </div><!-- /.blog-one__content -->
                        </div><!-- /.blog-one__single -->
                    </div><!-- /.col-lg-4 -->
                    <div class="col-lg-4">
                        <div class="blog-one__single">
                            <div class="blog-one__image">
                                <img src="<?=base_url();?>assets/img/bengkel.jpg" alt="">
                                <a class="blog-one__plus" href="news-details.html"><i class="kipso-icon-plus-symbol"></i>
                                    <!-- /.kipso-icon-plus-symbol --></a>
                            </div><!-- /.blog-one__image -->
                            <div class="blog-one__content text-center">
                                <h2>Tittle</h2>                                
                                <p class="blog-one__text">Deskripsi</p><!-- /.blog-one__text -->
                                <a href="news-details.html" class="blog-one__link">Read More</a><!-- /.blog-one__link -->
                            </div><!-- /.blog-one__content -->
                        </div><!-- /.blog-one__single -->
                    </div><!-- /.col-lg-4 -->
                    <div class="col-lg-4">
                        <div class="blog-one__single">
                            <div class="blog-one__image">
                                <img src="<?=base_url();?>assets/img/lab_komputer.jpg" alt="">
                                <a class="blog-one__plus" href="news-details.html"><i class="kipso-icon-plus-symbol"></i>
                                    <!-- /.kipso-icon-plus-symbol --></a>
                            </div><!-- /.blog-one__image -->
                            <div class="blog-one__content text-center">
                                <h2>Tittle</h2>                        
                                <p class="blog-one__text">Deskripsi</p><!-- /.blog-one__text -->
                                <a href="news-details.html" class="blog-one__link">Read More</a><!-- /.blog-one__link -->
                            </div><!-- /.blog-one__content -->
                        </div><!-- /.blog-one__single -->
                    </div><!-- /.col-lg-4 -->
                <div class="post-pagination col-lg-12">
                    <a href="#"><i class="fa fa-angle-double-left"></i><!-- /.fa fa-angle-double-left --></a>
                    <a class="active" href="#">1</a>
                    <a href="#">2</a>
                    <a href="#">3</a>
                    <a href="#">4</a>
                    <a href="#"><i class="fa fa-angle-double-right"></i><!-- /.fa fa-angle-double-left --></a>
                </div><!-- /.post-pagination -->
            </div><!-- /.container -->
        </section><!-- /.blog-one blog-page -->    