<?php $this->load->view('layout/tambahan') ?>
<?php $this->load->view('layout/header') ?>

<section class="team-details">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="blog-one__single">
                            <div class="blog-one__image2">
                                <img src="<?=base_url();?>assets/img/animasi.jpg" alt="">
                            </div><!-- /.blog-one__image -->
                        </div><!-- /.blog-one__single -->
                    </div><!-- /.col-lg-8 -->
                    <div class="col-lg-6">
                        <div class="sidebar">
                            <div class="sidebar__single sidebar__search">
                                 <h2 class="blog-one__title">Kompetensi Keahlian Animasi
                                </h2><!-- /.blog-one__title -->
                                <p class="blog-one__text">Kompetensi keahlian Animasi merupakah salah satu kompetensi yang dimiliki oleh SMKN 14 Kota Bandung. Kompetensi Animasi adalah salah satu cabang dari keilmuan seni rupa, dengan kompetensi utama seni rupa, khususnya Menggambar. Kompetensi animasi, diharapkan mampu mencetak calon calon animator , yakni pembuat FILM ANIMAS dll.
                                </p><!-- /.blog-one__text -->
                             </div><!-- /.sidebar__single -->
                        </div><!-- /.sidebar -->
                    </div><!-- /.col-lg-4 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
</section><!-- /.blog-details -->