<?php $this->load->view('layout/tambahan') ?>
<?php $this->load->view('layout/header') ?>


<section class="team-details">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="blog-one__single">
                            <div class="blog-one__image2">
                                <img src="<?=base_url();?>assets/img/tesktil.jpg" alt="">
                            </div><!-- /.blog-one__image -->
                        </div><!-- /.blog-one__single -->
                    </div><!-- /.col-lg-8 -->
                    <div class="col-lg-6">
                        <div class="sidebar">
                            <div class="sidebar__single sidebar__search">
                                 <h2 class="blog-one__title">Kompetensi Keahlian Kriya Kreatif Tekstil dan Batik
                                </h2><!-- /.blog-one__title -->
                                <p class="blog-one__text">Kompetensi Keahlian Kriya Kreatif Kulit dan Imitasi merupakah salah satu jurusan yang dimiliki oleh SMKN 14 Kota Bandung dalam mempersiapkan lulusan untuk mengisi peluang kerja tingkat menengah dalam Bidang Desain dan Produksi Kriya Tekstil yang profesional, produktif, dan memiliki wawasan budaya kerja.
                                </p><!-- /.blog-one__text -->
                                <p class="blog-one__text" style="font-weight: bold;">Visi Paket Keahlian Kriya Kreatif Tekstil dan Batik
                                	<br>
                                	<P>Menjadi Program Keahlian Unggulan Tingkat Nasional</p>

                                </p><!-- /.blog-one__text -->
                                <br>

                                <p class="blog-one__text" style="font-weight: bold;">Misi Paket Keahlian Kriya Kreatif Tekstil dan Batik

                                	<br>
                                	<P>Mempersiapkan tenaga kerja menengah dalam bidang Kriya Tekstil yang berwawasan profesional, kreatif, produktif, inovatif dan mampu menciptakan lapangan kerja sendiri untuk dapat bersaing di era globalisasi.</p>

                                </p><!-- /.blog-one__text -->
                             </div><!-- /.sidebar__single -->
                        </div><!-- /.sidebar -->
                    </div><!-- /.col-lg-4 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
</section><!-- /.blog-details -->