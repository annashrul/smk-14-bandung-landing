<?php $this->load->view('layout/tambahan') ?>
<?php $this->load->view('layout/header') ?>


<section class="team-details">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="blog-one__single">
                            <div class="blog-one__image2">
                                <img src="<?=base_url();?>assets/img/keramik.jpg" alt="">
                            </div><!-- /.blog-one__image -->
                        </div><!-- /.blog-one__single -->
                    </div><!-- /.col-lg-8 -->
                    <div class="col-lg-6">
                        <div class="sidebar">
                            <div class="sidebar__single sidebar__search">
                                 <h2 class="blog-one__title">Kompetensi Keahlian Kriya Kreatif Keramik
                                </h2><!-- /.blog-one__title -->
                                <p class="blog-one__text">Kompetensi keahlian Kriya Kreatif Keramik merupakan salah satu jurusan yang dimiliki oleh SMKN 14 Kota Bandung dalam mempersiapkan lulusan untuk mengisi peluang Bekerja tingkat menengah dalam bidang Seni Rupa, Kria, dan Teknologi yang berwawasan profesional, produktif, dan memiliki budaya kerja
                                </p><!-- /.blog-one__text -->
                                <p class="blog-one__text" style="font-weight: bold;">Visi Paket Keahlian Kriya Kreatif Keramik
                                	<br>
                                	<p>Menjadikan Tempat Pendidikan dan Pelatihan (Diklat) Kriya Keramik Unggulan</p>

                                </p><!-- /.blog-one__text -->
                                <br>

                                <p class="blog-one__text" style="font-weight: bold;">Misi Paket Keahlian Kriya Kreatif Keramik

                                	<br>
                                	<P>1) Menghasilkan tamatan siap bekerja,
<br>2) Menghasilkan tamatan bisa melanjutkan ke jenjang pendidikan yang lebih tinggi,
<br>3) Menghasilkan tamatan yang mampu mengembangkan wirausaha bidang kriya keramik</p>

                                </p><!-- /.blog-one__text -->
                             </div><!-- /.sidebar__single -->
                        </div><!-- /.sidebar -->
                    </div><!-- /.col-lg-4 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
</section><!-- /.blog-details -->