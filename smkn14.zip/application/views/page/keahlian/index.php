<?php 
	$this->load->view('page/keahlian/otomotif');
	$this->load->view('page/keahlian/multimedia');
	$this->load->view('page/keahlian/design');
	$this->load->view('page/keahlian/animasi');
	$this->load->view('page/keahlian/tesktil');
	$this->load->view('page/keahlian/logam');
	$this->load->view('page/keahlian/kulit');
	$this->load->view('page/keahlian/keramik');
	$this->load->view('page/keahlian/kayu');
		

 ?>