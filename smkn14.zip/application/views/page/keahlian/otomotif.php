<?php $this->load->view('layout/tambahan') ?>
<?php $this->load->view('layout/header') ?>


<section class="team-details">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="blog-one__single">
                            <div class="blog-one__image2">
                                <img src="<?=base_url();?>assets/img/otomotif.jpg" alt="">
                            </div><!-- /.blog-one__image -->
                        </div><!-- /.blog-one__single -->
                    </div><!-- /.col-lg-8 -->
                    <div class="col-lg-6">
                        <div class="sidebar">
                            <div class="sidebar__single sidebar__search">
                                 <h2 class="blog-one__title">Kompetensi Keahlian Teknik Bodi Otomotif
                                </h2><!-- /.blog-one__title -->
                                <p class="blog-one__text">Kompetensi keahlian Teknik perbaikan bodi otomotif merupakah salah satu kompetensi teknik yang dimiliki oleh SMKN 14 Kota Bandung. Didalam teknik bodi otomotif ini siswa dilatih untuk menjadi seorang tehnisi spesialis dalam hal bagian keindahan bodi kendaraan yang terdiri dari interior maupun exterior.
                                </p><!-- /.blog-one__text -->
                                <p class="blog-one__text" style="font-weight: bold;">Visi Paket Keahlian Teknik Bodi Otomotif
                                	<br>
                                	<P>Menjadi Kompetensi Keahlian Teknik body otomotif terkemuka dalam pengembangan potensi didik di bidang akademik dan mampu bersaing ditingkat nasional.</P>

                                </p><!-- /.blog-one__text -->
                                <br>

                                <p class="blog-one__text" style="font-weight: bold;">Misi Paket Keahlian Teknik Bodi Otomotif

                                	<br>
                                	<P>Menghasilkan lulusan dengan keunggulan kompetitif di bidang akademik melahirkan ide yang unik, cerdas serta berkelanjutan dikenal secara luas sebagai paket keahlian yang melestarikan seni dan budaya bangsa Indonesia.</p>

                                </p><!-- /.blog-one__text -->
                             </div><!-- /.sidebar__single -->
                        </div><!-- /.sidebar -->
                    </div><!-- /.col-lg-4 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
</section><!-- /.blog-details -->