<?php $this->load->view('layout/tambahan') ?>
<?php $this->load->view('layout/header') ?>


<section class="team-details">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="blog-one__single">
                            <div class="blog-one__image2">
                                <img src="<?=base_url();?>assets/img/logam.jpg" alt="">
                            </div><!-- /.blog-one__image -->
                        </div><!-- /.blog-one__single -->
                    </div><!-- /.col-lg-8 -->
                    <div class="col-lg-6">
                        <div class="sidebar">
                            <div class="sidebar__single sidebar__search">
                                 <h2 class="blog-one__title">Kompetensi Keahlian Kriya Kreatif Logam dan Perhiasan
                                </h2><!-- /.blog-one__title -->
                                <p class="blog-one__text">Kompetensi keahlian Teknik perbaikan bodi otomotif merupakah salah satu kompetensi teknik yang dimiliki oleh SMKN 14 Kota Bandung. Didalam teknik bodi otomotif ini siswa dilatih untuk menjadi seorang tehnisi spesialis dalam hal bagian keindahan bodi kendaraan yang terdiri dari interior maupun exterior.
                                </p><!-- /.blog-one__text -->
                                <p class="blog-one__text" style="font-weight: bold;">Visi Paket Keahlian Kriya Kreatif Logam dan Perhiasan
                                	<br>
                                	<P>Menjadi tempat pendidikan dan pelatihan (diklat) kompetensi keahlian DPK logam.</P>

                                </p><!-- /.blog-one__text -->
                                <br>

                                <p class="blog-one__text" style="font-weight: bold;">Misi Paket Keahlian Kriya Kreatif Logam dan Perhiasan

                                	<br>
                                	<P>1) Menghasilkan tamatan menjadi tenaga kerja menengah profesional di bidang kriya logam;
<br>2) Melaksanakan dan mengembangkan kompetensi-kompetensi unggulan dalam bidang kriya logam;
<br>3) Melaksanakan KBM secara kompetitif dan produktif;
<br>4) Melaksanakan kegiatan produksi dan jasa untuk kompetensi-kompetensi unggulan;
<br>5) Menambahkan sikap dan budi pekerti, santun, keagamaan antara guru, karyawan, siswa dan lulusan;</p>

                                </p><!-- /.blog-one__text -->
                             </div><!-- /.sidebar__single -->
                        </div><!-- /.sidebar -->
                    </div><!-- /.col-lg-4 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
</section><!-- /.blog-details -->