<?php $this->load->view('layout/tambahan') ?>
<?php $this->load->view('layout/header') ?>


<section class="team-details">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="blog-one__single">
                            <div class="blog-one__image2">
                                <img src="<?=base_url();?>assets/img/kulit.jpg" alt="">
                            </div><!-- /.blog-one__image -->
                        </div><!-- /.blog-one__single -->
                    </div><!-- /.col-lg-8 -->
                    <div class="col-lg-6">
                        <div class="sidebar">
                            <div class="sidebar__single sidebar__search">
                                 <h2 class="blog-one__title">Kompetensi Keahlian Kriya Kreatif Kulit dan Imitasi
                                </h2><!-- /.blog-one__title -->
                                <p class="blog-one__text">Jurusan Kriya Kreatif Kulit dan Imitasi merupakah salah satu jurusan yang dimiliki oleh SMKN 14 Kota Bandung yang membekali peserta didik dengan keterampilan, pengetahuan dan sikap agar kompeten :

                                </p><!-- /.blog-one__text -->
                                <p class="blog-one__text" style="font-weight: bold;">Visi Paket Keahlian Kriya Kreatif Kulit dan Imitasi
                                	<br>
                                	<P>Menjadi Program Keahlian unggulan bertaraf Nasional dalam bidang Desain dan Produksi Kriya Kulit.</p>

                                </p><!-- /.blog-one__text -->
                                <br>

                                <p class="blog-one__text" style="font-weight: bold;">Misi Paket Keahlian Kriya Kreatif Kulit dan Imitasi

                                	<br>
                                	<p>Mempersiapkan tenaga kerja tingkat menengah dalam bidang Kriya Kulit yang berwawasan, professional, produktif dan memiliki budaya tertib dan budaya bersih untuk menjadi manusia unggulan yang jujur dan mandiri.</p>

                                </p><!-- /.blog-one__text -->
                             </div><!-- /.sidebar__single -->
                        </div><!-- /.sidebar -->
                    </div><!-- /.col-lg-4 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
</section><!-- /.blog-details -->