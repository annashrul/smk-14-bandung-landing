<?php 

include 'header.php';
include 'navbar.php';
// include 'tambahan.php';
include "sidebar.php";
include "content.php";
include "footer.php";
 ?>