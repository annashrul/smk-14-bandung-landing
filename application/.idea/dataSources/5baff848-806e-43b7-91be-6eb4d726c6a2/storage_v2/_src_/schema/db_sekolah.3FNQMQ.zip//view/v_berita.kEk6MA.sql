create view v_berita as
  select
    `ta`.`id`          AS `id`,
    `ta`.`id_member`   AS `id_member`,
    `ta`.`id_category` AS `id_category`,
    `ta`.`title`       AS `title`,
    `ta`.`slug`        AS `slug`,
    `ta`.`content`     AS `content`,
    `ta`.`image`       AS `image`,
    `ta`.`tags`        AS `tags`,
    `ta`.`status`      AS `status`,
    `ta`.`type`        AS `type`,
    `ta`.`created_at`  AS `created_at`,
    `ta`.`updated_at`  AS `updated_at`,
    `tu`.`nama`        AS `nama`,
    `tc`.`title`       AS `category`
  from ((`db_sekolah`.`tbl_berita` `ta` left join `db_sekolah`.`tbl_category` `tc`
      on ((`tc`.`id` = `ta`.`id_category`))) left join `db_sekolah`.`tbl_user` `tu`
      on ((`tu`.`id` = `ta`.`id_member`)));

